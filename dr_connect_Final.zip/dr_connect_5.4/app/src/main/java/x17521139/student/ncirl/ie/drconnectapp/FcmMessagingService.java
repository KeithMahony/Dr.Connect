package x17521139.student.ncirl.ie.drconnectapp;
//@author Matthew Byrne x17138744 - Messaging service
//@author Ben Carroll x17501726 - design, layout, page links
//@author Keith Mahony x17521139 - Read data from Firebase, automated maintenance of database info
//@author Piyush Sharma x17342356 - Firebase Coordination
//@author Dylan Murphy x17506166 - Firebase Coordination

import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class FcmMessagingService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        if (remoteMessage.getData().size() > 0)
        {
            String title = remoteMessage.getData().get("title");
            String message = remoteMessage.getData().get("message");
            Intent intent = new Intent("x17521139.student.ncirl.ie.drconnectapp_FCM-MESSAGE");
            intent.putExtra("title", title);
            intent.putExtra("message", message);
            LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(this);
            localBroadcastManager.sendBroadcast(intent);
        }
    }
}


