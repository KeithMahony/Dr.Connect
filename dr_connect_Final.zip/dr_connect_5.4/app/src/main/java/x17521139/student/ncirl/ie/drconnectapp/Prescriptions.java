package x17521139.student.ncirl.ie.drconnectapp;

//@author Keith Mahony x17521139 - Read data from Firebase, automated maintenance of database info
//@author Ben Carroll x17501726 - design, layout, page links, attempted data puling from firebase
//@author Matthew Byrne x17138744 - visuals/imagery
//@author Piyush Sharma x17342356 - Firebase Coordination
//@author Dylan Murphy x17506166 - Firebase Coordination

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Prescriptions extends AppCompatActivity {

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    private DocumentReference noteRef;
    private DocumentReference emailRef;
    private FirebaseAuth mAuth;

    private static final String TAG = "Prescriptions";

    private static final String DESC = "description";
    private static final String DOCID = "DocID";
    private static final String PATID = "PatientID";
    private static final String MED1 = "med1";
    private static final String MED2 = "med2";
    private static final String MED3 = "med3";

    private String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

    String userEmail = user.getEmail();

    private TextView textViewData;
    private Button getDataBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescriptions);
        initialiseUI();
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        mAuth = FirebaseAuth.getInstance();

        noteRef = db.document("Prescription/"+userEmail);

        noteRef.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            String desc = documentSnapshot.getString(DESC);
                            String docID = documentSnapshot.getString(DOCID);
                            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                            String med1 = documentSnapshot.getString(MED1);
                            String med2 = documentSnapshot.getString(MED2);
                            String med3 = documentSnapshot.getString(MED3);

                            textViewData.setText( "\n"+"Doctor: " + docID + "\n"+ "\n" + "\n"+ "Patient ID: "+uid+ "\n"+ "\n" + "\n"+ "Description: " + desc+ "\n" + "\n" + "\n"+ "Medication 1: "+med1+"\n"+"Medication 2: "+med2+"\n"+"Medication 3: "+med3 );
                        } else {
                            Toast.makeText(Prescriptions.this, "Document does not exist", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Prescriptions.this, "Error!", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
        getDataBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                noteRef = db.document("Prescription/"+uid);
                fixDatabaseUID();
                loadPres(v);
            }
        });
    }
    public void fixDatabaseUID() {
        Map<String, Object> info = new HashMap<>();
        info.put("PatientID", uid);

        db.collection("Prescription").document(uid)
                .update("PatientID", uid)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });
    }
    public void loadPres(View v) {
        noteRef.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            String desc = documentSnapshot.getString(DESC);
                            String docID = documentSnapshot.getString(DOCID);
                            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                            String med1 = documentSnapshot.getString(MED1);
                            String med2 = documentSnapshot.getString(MED2);
                            String med3 = documentSnapshot.getString(MED3);

                            textViewData.setText( "\n"+"Doctor: " + docID + "\n"+ "\n" + "\n"+ "Patient ID: "+uid+ "\n"+ "\n" + "\n"+ "Description: " + desc+ "\n" + "\n" + "\n"+ "Medication 1: "+med1+"\n"+"Medication 2: "+med2+"\n"+"Medication 3: "+med3 );
                        } else {
                            Toast.makeText(Prescriptions.this, "Document does not exist", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Prescriptions.this, "Error!", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }
    public void initialiseUI(){
        textViewData = findViewById(R.id.textViewData2);
        getDataBtn = findViewById(R.id.getDataBtn);
    }
}

