package x17521139.student.ncirl.ie.drconnectapp;
//@author Keith Mahony x17521139 - Write data to Firebase, add doctor details
//@author Ben Carroll x17501726 - design, layout, page links, text validation
//@author Matthew Byrne x17138744 - visuals/imagery
//@author Piyush Sharma x17342356 - Firebase Coordination
//@author Dylan Murphy x17506166 - Firebase Coordination

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.type.Date;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class Appointments extends AppCompatActivity {

    private EditText dateTf, timeTf, locTf;
    private Button submitBtn;
    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private static final String TAG = "Appointments";
    private static String FNAME = "fName";
    private static String LNAME = "lName";
    private DocumentReference noteRef;
    private Timestamp TimeStamp;
    private SimpleDateFormat SimpleDateFormat;
    public Date Date;

    FirebaseFirestore db = FirebaseFirestore.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointments);

        FirebaseApp.initializeApp(this);
        initializeUI();
        mAuth = FirebaseAuth.getInstance();
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        //Static doctor address until fix is found
        noteRef = db.document("Patient/GqrgNAObTePieIH2MqNTKsCYgAb2");

        submitBtn = (Button) findViewById(R.id.submitBtn);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addAppointment();
                //addDetails();
            }
        });
    }

    private void addAppointment(){
        noteRef.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            String fName = documentSnapshot.getString(FNAME);
                            String lName = documentSnapshot.getString(LNAME);

                            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

                            String loc = locTf.getText().toString();

                            //String dateOb = new SimpleDateFormat("dd/MM/yyyy").format(dateObject);

                            Map<String, Object> info = new HashMap<>();
                            info.put("Address", loc);
                            info.put("Date", new Timestamp(new java.util.Date()));
                            info.put("name", fName+" "+lName);

                            db.collection("Doctor").document(uid).collection("Appointment")
                                    .add(info)
                                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                        @Override
                                        public void onSuccess(DocumentReference documentReference) {
                                            Log.d(TAG, "Document Snapshot successfully written!" +documentReference.getId());
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.w(TAG, "Error writing document", e);
                                        }
                                    });

                            //String description = documentSnapshot.getString(DOCNUM);

                            //Map<String, Object> note = documentSnapshot.getData();

                        } else {
                            Toast.makeText(Appointments.this, "Document does not exist", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Appointments.this, "Error!", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });

    }

    private void addDetails(){

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        String Address = "address";
        String DocID= "D1001";
        String Eircode="kkk3838";
        String fName = "fname";
        String sName= "Sname";
        String Town="Random town";
        String email= "sample@gmail.com";
        String phone="0893737783";

        Map<String, Object> info = new HashMap<>();
        info.put("Address", Address);
        info.put("DocID", DocID);
        info.put("Eircode", Eircode);
        info.put("Fname", fName);
        info.put("Sname", sName);
        info.put("Town", Town);
        info.put("email", email);
        info.put("phone", phone);


        db.collection("Doctor").document(uid)
                .set(info)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Document Snapshot successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });
    }

    private void initializeUI() {
        dateTf = findViewById(R.id.dateTf);
        locTf = findViewById(R.id.locTf);
    }

}

