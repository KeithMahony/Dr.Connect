package x17521139.student.ncirl.ie.drconnectapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class Doctor extends AppCompatActivity {

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    //FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();

    //uid = currentFirebaseUser.toText().toString();

    private DocumentReference noteRef;




    private static final String TAG = "Doctor";

    private static final String EMAIL = "Email";
    private static final String DOCID = "DocID";
    private static final String PHONE = "Phone";
    private static final String FNAME = "fName";
    private static final String LNAME = "lName";

    private String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

    private TextView textViewData;
    private Button getDataBtn;
    private Button uidBtn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor);
        initialiseUI();
        getUID();
        //uid = user.toString();
        //mAuth = FirebaseAuth.getInstance();
        //String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        getDataBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                noteRef = db.document("Doctor/"+uid);
                loadNote(v);
            }
        });

        uidBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getUID();
            }
        });
    }

    public void loadNote(View v) {
        noteRef.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            String email = documentSnapshot.getString(EMAIL);
                            String docID = documentSnapshot.getString(DOCID);
                            String phone = documentSnapshot.getString(PHONE);
                            String fName = documentSnapshot.getString(FNAME);
                            String lName = documentSnapshot.getString(LNAME);

                            //String description = documentSnapshot.getString(DOCNUM);

                            //Map<String, Object> note = documentSnapshot.getData();

                            textViewData.setText( "\n"+"Doctor ID: " + docID + "\n"+ "\n" + "\n"+ "Name: " + fName+" "+lName+ "\n" + "\n" + "\n"+ "Phone: "+phone+ "\n" + "\n" + "\n"+"Email: "+email+ "\n" + "\n");
                        } else {
                            Toast.makeText(Doctor.this, "Document does not exist", Toast.LENGTH_SHORT).show();
                        }


                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Doctor.this, "Error!", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }

    public void getUID() {
        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();
    }


    public void initialiseUI(){
        textViewData = findViewById(R.id.textViewData);
        getDataBtn = findViewById(R.id.getDataBtn);
        uidBtn = findViewById(R.id.uidBtn);
    }
}
