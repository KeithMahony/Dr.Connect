package x17521139.student.ncirl.ie.drconnectapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private DocumentReference noteRef;

    private Button logInBtn, account;
    private EditText cEmailTf, passwordTf;

    private static final String FNAME = "fName";
    private static final String LNAME = "lName";

    private ProgressBar progressBar;
    private FirebaseAuth mAuth;

    private String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        initializeUI();

        logInBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                noteRef = db.document("Patients/"+uid);
                loginUserAccount();
            }
        });

        account = (Button)findViewById(R.id.createBtn);
        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAccount();
            }
        });

        cEmailTf.addTextChangedListener(loginTextWatcher);
        passwordTf.addTextChangedListener(loginTextWatcher);

    }

    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String emailInput = cEmailTf.getText().toString().trim();
            String passwordInput = passwordTf.getText().toString().trim();

            logInBtn.setEnabled(!emailInput.isEmpty() && !passwordInput.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };



    private void loginUserAccount() {


        progressBar.setVisibility(View.VISIBLE);

        String email, password;
        email = cEmailTf.getText().toString();
        password = passwordTf.getText().toString();

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getApplicationContext(), "Please enter email...", Toast.LENGTH_LONG).show();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getApplicationContext(), "Please enter password!", Toast.LENGTH_LONG).show();
            return;
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Login successful! Welcome ", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);

                            Intent intent = new Intent(MainActivity.this, HomePage.class);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Login failed! Please try again later", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
    }
    public void openLogIn(){
        Intent intentLogIn = new Intent(this, HomePage.class);
        startActivity(intentLogIn);
    }

    public void openAccount(){
        Intent intentLogIn = new Intent(this, CreateAccount.class);
        startActivity(intentLogIn);
    }

    private void initializeUI() {
        cEmailTf = findViewById(R.id.cEmailTf);
        passwordTf = findViewById(R.id.passwordTf);

        logInBtn = findViewById(R.id.logInBtn);
        progressBar = findViewById(R.id.progressBar2);
    }
}
