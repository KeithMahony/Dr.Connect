package x17521139.student.ncirl.ie.drconnectapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class CreateAccount extends AppCompatActivity {
    private EditText fnameTf, lnameTf, cEmailTf, password1Tf, phoneTf, countyTf;
    private Button createBtn;
    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private static final String TAG = "CreateAccount";

    //private DocumentReference noteRef;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_account);
        FirebaseApp.initializeApp(this);

        mAuth = FirebaseAuth.getInstance();

        Button loginBtn = (Button) findViewById(R.id.logInBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });

        createBtn = (Button) findViewById(R.id.createBtn);
        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerNewUser();
                addName();
            }
        });
        initializeUI();

        fnameTf.addTextChangedListener(createTextWatcher);
        lnameTf.addTextChangedListener(createTextWatcher);
        cEmailTf.addTextChangedListener(createTextWatcher);
        password1Tf.addTextChangedListener(createTextWatcher);
        phoneTf.addTextChangedListener(createTextWatcher);
        countyTf.addTextChangedListener(createTextWatcher);
    }



    private void registerNewUser() {
        progressBar.setVisibility(View.VISIBLE);
        String email, password;
        email = cEmailTf.getText().toString();
        password = password1Tf.getText().toString();

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getApplicationContext(), "Please enter email...", Toast.LENGTH_LONG).show();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getApplicationContext(), "Please enter password!", Toast.LENGTH_LONG).show();
            return;
        }

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                            //noteRef = db.document("Patient/"+uid);

                            Toast.makeText(getApplicationContext(), "Registration successful!", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);

                            Intent intent = new Intent(CreateAccount.this, HomePage.class);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Registration failed! Please try again later", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });

    }

    private TextWatcher createTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String fnameInput = fnameTf.getText().toString();
            String lnameInput = lnameTf.getText().toString();
            String cEmailInput = cEmailTf.getText().toString();
            String password1Input = password1Tf.getText().toString();
            String countyInput = countyTf.getText().toString();
            String phoneInput = phoneTf.getText().toString();

            createBtn.setEnabled(!fnameInput.isEmpty() && !lnameInput.isEmpty() && !cEmailInput.isEmpty() && !password1Input.isEmpty()&& !countyInput.isEmpty()&& !phoneInput.isEmpty() );
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    private void addName(){

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        String fname = fnameTf.getText().toString();
        String lname = lnameTf.getText().toString();
        String email = cEmailTf.getText().toString();
        String phone = phoneTf.getText().toString();
        String county = countyTf.getText().toString();

        Map<String, Object> info = new HashMap<>();
        info.put("pID", uid);
        info.put("fName", fname);
        info.put("lName", lname);
        info.put("phone", phone);
        info.put("email", email);
        info.put("county", county);

        db.collection("Patient").document(uid)
                .set(info)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Document Snapshot successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });
    }

    private void initializeUI() {
        fnameTf = findViewById(R.id.fnameTf);
        lnameTf = findViewById(R.id.lnameTf);
        cEmailTf = findViewById(R.id.cEmailTf);
        password1Tf = findViewById(R.id.password1Tf);
        createBtn = findViewById(R.id.createBtn);
        progressBar = findViewById(R.id.progressBar);
        phoneTf = findViewById(R.id.phoneTf);
        countyTf = findViewById(R.id.countyTf);

    }
}
